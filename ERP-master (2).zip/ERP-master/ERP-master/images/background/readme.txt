Upload all images which is used in background purpose.
