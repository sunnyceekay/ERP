<?php
    $username = "root";
    $password = "powerrights";
    $host = "localhost";
    $database = "erp";
    $conn = new mysqli($host,$username,$password,$database);
   
?>