<?php
    echo ' </div>
    </div>
    <p class = footer>Unpublished work &copy; '.date("Y").' Suman Das</p>
<script src = "../javascript/layout.js"></script>
</body>
</html>'
?>