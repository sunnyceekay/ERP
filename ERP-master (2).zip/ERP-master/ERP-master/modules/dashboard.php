<?php include "../php/start.php" ?>
                <h3><center>This is your Dashboard</center></h3>
<?php include "../php/end.php" ?>